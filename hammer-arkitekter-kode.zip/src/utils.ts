export const triggerHaptic = () => {};
